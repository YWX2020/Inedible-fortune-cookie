Audio Unfortunately not working on the .exe file(inedible fortune cookies).
If possible, please run using the source code, welcome.py, but would require
having pygame and tkinter. The exe file does not require having these extensions.